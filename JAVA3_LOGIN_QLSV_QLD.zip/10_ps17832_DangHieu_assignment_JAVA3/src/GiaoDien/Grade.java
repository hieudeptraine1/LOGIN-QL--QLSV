/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GiaoDien;

/**
 *
 * @author MINH HIEU
 */
public class Grade {
    String masv;
    String hoten;
    int tienganh;
    int tinhoc;
    int GDTC;
   // double diemTB;

    public Grade() {
    }

    public Grade(String masv, String hoten, int tienganh, int tinhoc, int GDTC) {
        this.masv = masv;
        this.hoten = hoten;
        this.tienganh = tienganh;
        this.tinhoc = tinhoc;
        this.GDTC = GDTC;
       //this.diemTB = diemTB;
    }

    public String getMasv() {
        return masv;
    }

    public void setMasv(String masv) {
        this.masv = masv;
    }

    public String getHoten() {
        return hoten;
    }

    public void setHoten(String hoten) {
        this.hoten = hoten;
    }

    public int getTienganh() {
        return tienganh;
    }

    public void setTienganh(int tienganh) {
        this.tienganh = tienganh;
    }

    public int getTinhoc() {
        return tinhoc;
    }

    public void setTinhoc(int tinhoc) {
        this.tinhoc = tinhoc;
    }

    public int getGDTC() {
        return GDTC;
    }

    public void setGDTC(int GDTC) {
        this.GDTC = GDTC;
    }

    public double getDiemTB() {
        return (this.tinhoc + this.tienganh + this.GDTC)/3.0;
    }

//    public void setDiemTB(double diemTB) {
//        this.diemTB = diemTB;
//    }
    
}
